#include "main.h"
#include "funciones.h"

int main()
{
    tIndice ind;
    tLista lista;
    FILE *fp;

    leerYMostrarArchivo(NOM_ARCH_MAESTRO);
    leerYMostrarArchivoDeTexto(NOM_ARCH_NOVEDAD);
    crearIndice(NOM_ARCH_MAESTRO, &ind, &lista, fp);

    actualizarMaestro(NOM_ARCH_MAESTRO, NOM_ARCH_NOVEDAD, &lista);
    return 0;
}
